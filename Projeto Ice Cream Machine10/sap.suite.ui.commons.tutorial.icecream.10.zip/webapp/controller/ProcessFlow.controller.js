sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("sap.suite.ui.commons.demokit.tutorial.icecream.10.controller.ProcessFlow", {
		onNavButtonPressed: function() {
			this.getOwnerComponent().getRouter().navTo("home");
		},

		getValuesDelta: function(fFirstValue, fSecondValue) {
			return fSecondValue - fFirstValue;
		}
	});
});
